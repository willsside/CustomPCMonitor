﻿using System;
using System.IO;
using System.IO.Ports;
using System.Threading;
using System.Management;
using OpenHardwareMonitor.Hardware;

public class CPUTemp2Arduino
{
    static SerialPort port;
    static int ardPortInd;
    static int CPUTemp;
    static int GPUTemp;
    static string path = "CPUTemp2Arduino_Log.txt";
    static string portPath = "INSERT_ARDIUNO_PORT_HERE.txt";

    public static void Main()
    {
        // Create port object
        port = new SerialPort();

        // Try to open port
        try
        {
            port.Parity = Parity.None;
            port.StopBits = StopBits.One;
            port.DataBits = 8;
            port.Handshake = Handshake.None;
            port.RtsEnable = true;
            port.BaudRate = 9600;
            string[] ports = SerialPort.GetPortNames();

            //Get stored Port address
            string portName = System.IO.File.ReadAllText(portPath);


            ardPortInd = Array.IndexOf(ports, portName);
            port.PortName = ports[ardPortInd];
        }
        catch (Exception ex)
        {
            using (StreamWriter sw = File.AppendText(path))
            {
                sw.WriteLine("ERROR: Error Finding port");
            }
            return;
        }

        // Attempt to open port
        try
        {
            if (!port.IsOpen)
            {
                port.Open();
            }
        }
        catch (Exception ex)
        {
            port.Close();
            using (StreamWriter sw = File.AppendText(path))
            {
                sw.WriteLine("ERROR: Error opening port");
            }
            return;
        }

        for (int i = 0; i < 100; i++) // looping for 100 hrs
        {
            // Attempt to write time to port
            try
            {
                // Get local time in unix
                var dateTime = DateTime.Now;
                var epoch = new DateTime(1970, 1, 1, 4, 0, 0, DateTimeKind.Utc); // add 4 hr shift to change to EST
                var unixDateTime = (dateTime.ToUniversalTime() - epoch).TotalSeconds;
                unixDateTime = Math.Round(unixDateTime);

                // Write time
                port.Write("T" + unixDateTime.ToString() + "\n");
            }
            catch (Exception ex)
            {
                port.Close();
                using (StreamWriter sw = File.AppendText(path))
                {
                    sw.WriteLine("ERROR: Error writing to port");
                }
                return;
            }

            //Open Log
            deleteAndOpenLog();
            
            for (int sec = 0; sec < 3600; sec++) // each hour update time and replace log
            {
                using (StreamWriter sw = File.AppendText(path))
                {
                    sw.WriteLine(DateTime.Now);
                    sw.WriteLine("Second: " + sec);
                    ManagementObjectSearcher searcher =
                        new ManagementObjectSearcher("root\\OpenHardwareMonitor",
                        "SELECT * FROM Sensor WHERE SensorType = 'Temperature'");

                    foreach (ManagementObject queryObj in searcher.Get())
                    {
                        if (String.Equals(queryObj["Name"], "CPU Package"))
                        {
                            CPUTemp = (int)decimal.Parse(queryObj["Value"].ToString());
                            sw.WriteLine("CPUTemp: " + CPUTemp);
                        }
                        if (String.Equals(queryObj["Name"], "GPU Core"))
                        {
                            GPUTemp = (int)decimal.Parse(queryObj["Value"].ToString());
                            sw.WriteLine("GPUTemp: " + GPUTemp);
                        }
                    }
                    sw.WriteLine("C" + CPUTemp.ToString() + GPUTemp.ToString() + "\n");
                }

                //Write to port
                port.Write("C" + CPUTemp.ToString() + GPUTemp.ToString() + "\n");
                Thread.Sleep(1000);
            }
        }
        //Close Port
        port.Write("DIS");
        port.Close();

        using (StreamWriter sw = File.AppendText(path))
        {
            sw.WriteLine("Closed Port: Disconnected");
        }
        }
    public static void deleteAndOpenLog()
    {
        try
        {
            // Check if file exists, delete   
            if (File.Exists(path))
            { 
                File.Delete(path);
            }
            // Create a file to write to.
            using (StreamWriter sw = File.CreateText(path))
            {
                sw.WriteLine("Log for CPUTemp2Arduino");
                sw.WriteLine(" ");
            }
        }
        catch (IOException ioExp)
        {
            Console.WriteLine("ERROR: Error opening / deleting log file");
            return;
        }
    }
}